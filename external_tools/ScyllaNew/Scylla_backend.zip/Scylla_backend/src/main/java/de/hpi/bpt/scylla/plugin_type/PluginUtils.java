package de.hpi.bpt.scylla.plugin_type;

public class PluginUtils {

    private static final String PLUGIN_ATTRIBUTE_NAME_DELIMITER = "_";

    public static String getPluginAttributeNameDelimiter() {
        return PLUGIN_ATTRIBUTE_NAME_DELIMITER;
    }

}
