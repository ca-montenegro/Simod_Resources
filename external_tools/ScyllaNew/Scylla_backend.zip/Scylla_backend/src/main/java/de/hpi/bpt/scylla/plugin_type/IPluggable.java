package de.hpi.bpt.scylla.plugin_type;

public interface IPluggable {

    String getName();
}
