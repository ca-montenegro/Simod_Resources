package de.hpi.bpt.scylla.plugin.gateway_exclusive;

public class ExclusiveGatewayPluginUtils {

    static final String PLUGIN_NAME = "gateway_exclusive";
}
