package de.hpi.bpt.scylla.plugin_type.parser;

import de.hpi.bpt.scylla.plugin_type.IPluggable;

public abstract class EventOrderType implements IEventOrderType, IPluggable {

}
