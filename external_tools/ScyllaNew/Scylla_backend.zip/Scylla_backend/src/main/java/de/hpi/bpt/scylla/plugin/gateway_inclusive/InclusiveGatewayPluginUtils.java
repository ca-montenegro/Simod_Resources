package de.hpi.bpt.scylla.plugin.gateway_inclusive;

public class InclusiveGatewayPluginUtils {

    static final String PLUGIN_NAME = "gateway_inclusive";
}
