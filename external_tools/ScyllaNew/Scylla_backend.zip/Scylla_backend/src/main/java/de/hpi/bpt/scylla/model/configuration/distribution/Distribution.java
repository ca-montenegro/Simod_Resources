package de.hpi.bpt.scylla.model.configuration.distribution;

public interface Distribution {}