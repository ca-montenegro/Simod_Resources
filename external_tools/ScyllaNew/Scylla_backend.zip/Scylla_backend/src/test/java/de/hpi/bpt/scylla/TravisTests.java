package de.hpi.bpt.scylla;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class TravisTests {
    /**
     * First test to validate that travis is working
     */
    @Test
    public void TravisIsWorking() {
        assertEquals(true, true);
    }
}